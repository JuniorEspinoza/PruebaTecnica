﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PruebaTecnica
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        

        public DispatcherTimer cronometro = new DispatcherTimer();
        public Tiempo oTiempo = new Tiempo();

       
        public MainWindow()
        {
            
            InitializeComponent();
            oTiempo.IniciarContador();
            txtsegundos.Text = oTiempo.Segundos.ToString();
            txtminutos.Text = oTiempo.Minutos.ToString();
            txthora.Text = oTiempo.Horas.ToString();

            cronometro.Interval = new TimeSpan(0, 0,0, 0, 500);
            cronometro.Tick += (a, b) =>
            {
                oTiempo.AvanzaCronometro();
                txtsegundos.Text = oTiempo.Segundos.ToString();
                txtminutos.Text = oTiempo.Minutos.ToString();
                txthora.Text = oTiempo.Horas.ToString();

            };
       
        }


        private void btnIniciar_Click(object sender, RoutedEventArgs e)
        {
            cronometro.Start();
        }

        private void btnPausa_Click(object sender, RoutedEventArgs e)
        {
            cronometro.Stop();
        }

        private void btnDetener_Click(object sender, RoutedEventArgs e)
        {
            oTiempo.IniciarContador();          
            cronometro.Stop();
        }
    }
}
