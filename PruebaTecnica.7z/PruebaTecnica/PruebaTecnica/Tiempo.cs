﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaTecnica
{
    public class Tiempo
    {
        public int Horas { get; set; }
        public int Minutos { get; set; }
        public int Segundos { get; set; }

        public void IniciarContador()
        {
            Horas = 0;
            Minutos = 0;
            Segundos = 0;
        }

        public void AvanzaCronometro()
        {
            Segundos = Segundos + 1;
            if (Segundos == 60)
            {
                Segundos = 0;
                Minutos = Minutos + 1;
                if (Minutos == 60)
                {
                    Minutos = 0;
                    Horas = Horas + 1;
                }
            }


        }

        
    }
}
